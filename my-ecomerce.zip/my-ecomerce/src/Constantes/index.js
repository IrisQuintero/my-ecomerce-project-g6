const firebaseConfig = {
  apiKey: "AIzaSyA7MT9eOtUpObFNOqqxQ7sh1_SNRu6Z9cw",
  authDomain: "g6-project-iris.firebaseapp.com",
  projectId: "g6-project-iris",
  storageBucket: "g6-project-iris.appspot.com",
  messagingSenderId: "138655005233",
  appId: "1:138655005233:web:7935cde7f80f152efb3310",
  measurementId: "G-52T08SBDQM"
};
 
  export {firebaseConfig};